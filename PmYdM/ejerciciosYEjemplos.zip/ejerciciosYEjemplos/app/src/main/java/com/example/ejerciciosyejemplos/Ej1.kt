package com.example.ejerciciosyejemplos

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun textoSimple(){
    Text("Hola mundo")
}