fun main(){
    val listNumero= listOf(1,2,3,4,5);
    println(listNumero.filter { numero->numero%2==0 });
}