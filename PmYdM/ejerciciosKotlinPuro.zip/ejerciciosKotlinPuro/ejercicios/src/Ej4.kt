fun main(){
    val listaNum=listOf(1,2,3,4,5);
    println(listaNum.sum());
}