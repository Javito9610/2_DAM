fun main(){
    fun mayor(a:Int,b:Int,c:Int)=maxOf(a,b,c);
    print(mayor(1,2,3));
}