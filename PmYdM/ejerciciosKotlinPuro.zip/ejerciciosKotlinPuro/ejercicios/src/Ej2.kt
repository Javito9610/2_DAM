const val PI=Math.PI;

    fun main(){
        val radio=5;
        val area=PI*(radio*radio);
        println(area);
        print(area.javaClass);
    }
