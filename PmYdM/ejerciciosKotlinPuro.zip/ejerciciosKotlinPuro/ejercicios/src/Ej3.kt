fun main(){
    val palabra="oso";
    println(palabra==palabra.reversed());
}